class Contact {
  String name;
  String phone;
  String email;
  bool isFavorite;
  String photo;

  Contact({
    required this.name,
    required this.phone,
    required this.email,
    this.isFavorite = false,
    required this.photo,
    
  });
}
