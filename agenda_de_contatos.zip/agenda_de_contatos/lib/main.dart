import 'package:agenda_de_contatos/screens/home/home.dart';
import 'package:flutter/material.dart';
void main() {
  runApp(
    MaterialApp(
      title: "Agenda de contatos",
      home:  Home(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.light(
          primary: Colors.red,
          secondary: Colors.orange,
        ),
        toggleableActiveColor: Colors.purple,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.light(
          primary: Colors.green.shade100,
          secondary: Colors.brown,
        ),
        toggleableActiveColor: Colors.yellow,
    ),
  ),
}
