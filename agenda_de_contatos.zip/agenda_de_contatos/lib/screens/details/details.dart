import 'package:flutter/material.dart';
import 'pachage:flutter/contact.dart';

class Details extends StatelessWidget {
   Contact contact;
   Details({
   super.key,
   required Contact contact,
   });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(contact.name),
      ),
      body: Container(
        child: Column(
          children: [
            Image.asset(
              contact.photo,
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    contact.name,
                    style: Theme.of(context).textTheme.headline5,
                  ),
                  Text(
                    contact.phone,
                    style: Theme.of(context).textTheme.bodyText2,
                  ),
                ],
              ),
            ),
            Checkbox(value: true, onChanged: (value) {})
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(onPressed: () {}, child: const Icon(Icons.edit,
      ),
      ),
    );
  }
}
