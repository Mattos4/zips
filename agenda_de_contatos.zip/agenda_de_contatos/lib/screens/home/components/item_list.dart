import 'package:agenda_de_contatos/model/contact.dart';
import 'package:flutter/material.dart';

class ItemList extends StatefulWidget {
  Contact contact;
  ItemList({
    Key? key,
    required this.contact,
  }) : super(key: key);

  @override
  State<ItemList> createState() => _ItemListState();
}

class _ItemListState extends State<ItemList> {
  @override
  Widget build(BuildContext context) {
    return Row(

      children: [
        Row(
  
          children: [
            showStar(
            isFavorite: widget.contact.
            isFavorite,
            ),
            const CircleAvatar(
              backgroundImage: AssetImage("assets/images/Nicole.jpg",),
            ),
        ClipOval(
           child: Hero(
           tag: "avatar",
            child: Image.asset(
              widget.contact.photo,
              width:40,
              height: 40,
              fit: BoxFit.cover,
            ),
            ),
            ),
            const SizedBox(
              width: 16,
            ),
                  Column(
              crossAxisAlignment: 
              CrossAxisAlignment.start,
              children: [
                Text(
                  widget.contact.name,
                ),
                Text(
                  widget.contact.phone
                ),
              ],
            ),
          ],
        ),
        IconButton(
          onPressed: () {
            Navigator.push(
            context,
          MaterialPageRoute(
            builder: (_) => Details(
              contact: widget.contact,
             ),
            ),
           );
          },
          icon: const Icon (
            Icons.chevron_right,
          ),
        )
      ],
    );
  }

  IconButton showStar({bool isFavorite = false}) {
    if (isFavorite) {
      return IconButton(
        onPressed: () {
          setState(() {widget.contact.isFavorite = });
        },
        icon: Icon(Icons.star),
      );
    }
    return  IconButton(
      onPressed: () {},
      icon: Icon(Icons.star_border),
      color: Colors.red,
    );
  }
}
