

import 'package:agenda_de_contatos/model/contact.dart';
import 'package:agenda_de_contatos/screens/home/components/item_list.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() {
    return _HomeState();
  }
}

class _HomeState extends State<Home> {
  List<Contact> contacts = [
    Contact(
      name: "Nicole",
      phone: "+55 51 11111-1111",
      email: "nicole.silva@gmail.com",
      photo: "assets/images/Nicole.jpg"
    ),
    Contact(
      name: "Camila",
      phone: "+55 51 22222-2222",
      email: "camila.nogueira@gmail.com",
      isFavorite: true,
      photo: "assets/images/Camila.jpg"
    ),
    Contact(
      name: "Paulo",
      phone: "+55 51 33333-3333",
      email: "paulo.silva@gmail.com",
      photo: "assets/images/Paulo.jpg"
    ),
    Contact(
      name: "Lucas",
      phone: "+55 51 44444-4444",
      email: "lucas.almeida@gmail.com",
      isFavorite: true,
      photo: "assets/images/Lucas.jpg"
    ),
  ];
  @override
  Widget build(Object context){
    return Scaffold(
      appBar: AppBar(
        title: Text("Meus contatos"),
      ),
      body: Container(
        margin: EdgeInsets.all(16),
        child: ListView.builder(
          itemBuilder: (context, index){
            return ItemList();
          },
          itemCount: contacts.length,
        ),
      ),
      floatingActionButton: Text ("Teste"),
    );
  }
}