package com.example.agenda_de_contatos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
